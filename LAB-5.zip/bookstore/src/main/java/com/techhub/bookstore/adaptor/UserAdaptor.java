package com.techhub.bookstore.adaptor;

import com.techhub.bookstore.dto.UserDTO;
import com.techhub.bookstore.model.User;

public final class UserAdaptor {

	private UserAdaptor() {
	}

	public static final UserDTO toUserDTO(User user) {
		UserDTO userDTO = new UserDTO();
		userDTO.setUsername(user.getUsername());
		userDTO.setPassword(user.getPassword());
		userDTO.setRoles(user.getRoles());
		userDTO.setAccountNonExpired(user.isAccountNonExpired());
		userDTO.setAccountNonLocked(user.isAccountNonLocked());
		userDTO.setCredentialsNonExpired(user.isCredentialsNonExpired());
		userDTO.setEnabled(user.isEnabled());
		return userDTO;
	}

	public static final User toUser(UserDTO userDTO) {
		User user = new User();
		user.setUsername(userDTO.getUsername());
		user.setPassword(userDTO.getPassword());
		user.setRoles(userDTO.getRoles());
		user.setAccountNonExpired(userDTO.isAccountNonExpired());
		user.setAccountNonLocked(userDTO.isAccountNonLocked());
		user.setCredentialsNonExpired(userDTO.isCredentialsNonExpired());
		user.setEnabled(userDTO.isEnabled());
		return user;
	}
}
