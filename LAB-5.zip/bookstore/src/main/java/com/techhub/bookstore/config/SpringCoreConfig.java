package com.techhub.bookstore.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.thymeleaf.extras.springsecurity6.dialect.SpringSecurityDialect;
import org.thymeleaf.spring6.SpringTemplateEngine;
import org.thymeleaf.spring6.templateresolver.SpringResourceTemplateResolver;
import org.thymeleaf.spring6.view.ThymeleafViewResolver;

@Configuration
public class SpringCoreConfig {

	/**
	 * SpringResourceTemplateResolver bean
	 * 
	 * @return SpringResourceTemplateResolver
	 */
	@Bean
	public SpringResourceTemplateResolver springResourceTemplateResolver() {
		SpringResourceTemplateResolver springResourceTemplateResolver = new SpringResourceTemplateResolver();
		springResourceTemplateResolver.setPrefix("/WEB-INF/ui/");
		springResourceTemplateResolver.setSuffix(".html");
		springResourceTemplateResolver.setTemplateMode("HTML5");
		return springResourceTemplateResolver;
	}

	/**
	 * SpringTemplateEngine bean
	 * 
	 * @return SpringTemplateEngine
	 */
	@Bean
	public SpringTemplateEngine springTemplateEngine(SpringResourceTemplateResolver springResourceTemplateResolver) {
		SpringTemplateEngine springTemplateEngine = new SpringTemplateEngine();
		springTemplateEngine.setTemplateResolver(springResourceTemplateResolver);
		SpringSecurityDialect springSecurityDialect = new SpringSecurityDialect();
		springTemplateEngine.addDialect(springSecurityDialect);
		return springTemplateEngine;
	}

	/**
	 * ThymeleafViewResolver bean
	 * 
	 * @return ThymeleafViewResolver
	 */
	@Bean
	public ThymeleafViewResolver thymeleafViewResolver(SpringTemplateEngine springTemplateEngine) {
		ThymeleafViewResolver thymeleafViewResolver = new ThymeleafViewResolver();
		thymeleafViewResolver.setTemplateEngine(springTemplateEngine);
		return thymeleafViewResolver;
	}
}
