package com.techhub.bookstore.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.techhub.bookstore.dto.UserDTO;
import com.techhub.bookstore.service.UserService;

@Controller
public class UserRegistrationController {

	@Autowired
	private UserService userService;

	@GetMapping("/user-register")
	public ModelAndView registerPage(Model model) {
		System.out.println("******* USER REGISTRATION PAGE *******");
		model.addAttribute("myuser", new UserDTO());
		return new ModelAndView("user-registration");
	}

	@PostMapping("/user-register")
	public ModelAndView registerRegister(@ModelAttribute("myuser") UserDTO myuser, Model model) {
		System.out.println("******* USER REGISTRATION *******");
		this.userService.saveUser(myuser);
		model.addAttribute("success_msg", "User registered successfully");
		return new ModelAndView("user-registration");
	}
}
