package com.techhub.bookstore.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;

@Controller
public class ErrorHanderController implements ErrorController {
	
	/** The ERROR URL */
	public static final String ERROR_URL = "/error";

	/** The REDIRECT_ERROR URL */
	public static final String REDIRECT_ERROR = "redirect:/error";

	/**
	 * Handle the error of server
	 * 
	 * @param request HttpServletRequest request type object
	 * @return ModelAndView a ModelAndView type object
	 */
	@RequestMapping(ERROR_URL)
	public ModelAndView handleError(HttpServletRequest httpServletRequest) {

		ModelAndView modelAndView = new ModelAndView("error");
		return modelAndView;
	}
}
