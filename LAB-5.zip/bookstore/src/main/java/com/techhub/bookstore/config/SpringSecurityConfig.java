package com.techhub.bookstore.config;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;
import org.springframework.security.web.access.AccessDeniedHandler;

@Configuration
public class SpringSecurityConfig {
	
	@Autowired
	private AccessDeniedHandler accessDeniedHandler;

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {
		
		httpSecurity = httpSecurity.authorizeHttpRequests(authorizeRequests -> {
			authorizeRequests.requestMatchers("/").permitAll();
			authorizeRequests.requestMatchers("/show-books").permitAll();	
			authorizeRequests.requestMatchers("/user-register").permitAll();	
		})	.authorizeHttpRequests(authorizeRequests -> {
			authorizeRequests.requestMatchers("/error").authenticated();
		})	.authorizeHttpRequests(authorizeRequests -> {
			authorizeRequests.requestMatchers("/add-book").hasAnyAuthority( "ADMIN", "STOREKEEPER");
			authorizeRequests.requestMatchers("/update-book").hasAnyAuthority("ADMIN", "STOREKEEPER");
			authorizeRequests.requestMatchers("/delete-book").hasAnyAuthority("ADMIN");
			authorizeRequests.requestMatchers("/place-order").hasAnyAuthority("CUSTOMER");
		}).formLogin(formLoginCustomizer -> {
			formLoginCustomizer
				.loginPage("/login")
				.loginProcessingUrl("/login")
				.failureUrl("/login-fail")
				.usernameParameter("username")
				.passwordParameter("password")
				.defaultSuccessUrl("/")
				.permitAll();
		}).logout(logoutCustomizer->{
			logoutCustomizer
			  	.logoutUrl("/logout")
			  	.invalidateHttpSession(true)
			  	.deleteCookies("JSESSIONID")
			  	.logoutSuccessUrl("/");
		})	.csrf(csrfCustomizer -> {
			csrfCustomizer.disable();
		}).exceptionHandling(exceptionHandlingCustomizer->{
			exceptionHandlingCustomizer.accessDeniedHandler(accessDeniedHandler);
		});
		return httpSecurity.build();
	}
}
