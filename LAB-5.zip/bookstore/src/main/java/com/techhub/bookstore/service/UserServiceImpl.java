package com.techhub.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.techhub.bookstore.adaptor.UserAdaptor;
import com.techhub.bookstore.dto.UserDTO;
import com.techhub.bookstore.model.User;
import com.techhub.bookstore.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;
	
	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public UserDTO getUserDTO(String username) {
		User user = userRepository.getReferenceById(username);
		if (user != null) {
			return UserAdaptor.toUserDTO(user);
		}
		return null;
	}

	@Override
	public UserDTO saveUser(UserDTO userDTO) {	
		String password=passwordEncoder.encode(userDTO.getPassword());
		userDTO.setPassword(password);
		User user=UserAdaptor.toUser(userDTO);
		user = this.userRepository.save(user);
		return UserAdaptor.toUserDTO(user);
	}
}
