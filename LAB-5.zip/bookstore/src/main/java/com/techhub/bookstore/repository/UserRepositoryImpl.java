//package com.techhub.bookstore.repository;
//
//import java.util.HashMap;
//import java.util.Map;
//
//import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
//import org.springframework.stereotype.Repository;
//
//import com.techhub.bookstore.model.User;
//
//import jakarta.annotation.PostConstruct;
//
//@Repository
//public class UserRepositoryImpl implements UserRepository {
//
//	private final Map<String, User> USERS = new HashMap<>();
//
//	@Autowired
//	private PasswordEncoder passwordEncoder;
//
//	@PostConstruct
//	public void setup(){
//		USERS.put("admin", new User("admin", passwordEncoder.encode("password1"), "ADMIN"));
//		USERS.put("usera", new User("usera", passwordEncoder.encode("password2"), "STOREKEEPER"));
//		USERS.put("userb", new User("userb", passwordEncoder.encode("password3"), "CUSTOMER"));
//		USERS.put("userc", new User("userc", passwordEncoder.encode("password4"), "CUSTOMER"));
//		USERS.put("userd", new User("userd", passwordEncoder.encode("password5"), "ADMIN,CUSTOMER"));
//	}
//
//	@Override
//	public User getUser(String username) {
//		return USERS.get(username);
//	}
//}
