package com.techhub.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.techhub.bookstore.adaptor.UserAdaptor;
import com.techhub.bookstore.dto.UserDTO;
import com.techhub.bookstore.repository.UserRepository;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Override
	public UserDTO getUserDTO(String username) {
		return UserAdaptor.toUserDTO(userRepository.getUser(username));
	}
}
