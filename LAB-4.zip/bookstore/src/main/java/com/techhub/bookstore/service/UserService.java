package com.techhub.bookstore.service;

import com.techhub.bookstore.dto.UserDTO;

public interface UserService {

	public UserDTO getUserDTO(String username);
}
