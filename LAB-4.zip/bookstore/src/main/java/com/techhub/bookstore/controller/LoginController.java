package com.techhub.bookstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;


@Controller
public class LoginController {

	@GetMapping("/login")
	public ModelAndView login() {
		System.out.println("******* LOGIN *******");
		return new ModelAndView("login");
	}

	@GetMapping("/login-fail")
	public ModelAndView loginFail(Model model) {
		System.out.println("******* LOGIN FAIL *******");
		ModelAndView modelAndView = new ModelAndView("login");
		model.addAttribute("error_msg", "Username or password incorrect");
		return modelAndView;
	}
}
