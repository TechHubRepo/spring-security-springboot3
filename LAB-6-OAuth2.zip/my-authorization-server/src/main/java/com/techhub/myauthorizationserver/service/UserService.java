package com.techhub.myauthorizationserver.service;

import com.techhub.myauthorizationserver.dto.UserDTO;

public interface UserService {
	
	public UserDTO getUser(String username);
	
	public UserDTO saveUser(UserDTO userDTO);

}
