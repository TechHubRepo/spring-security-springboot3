package com.techhub.myauthorizationserver.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.web.SecurityFilterChain;

@Configuration
public class SpringSecurityConfig {

	@Bean
	public PasswordEncoder passwordEncoder() {
		return new BCryptPasswordEncoder();
	}

	@Bean
	public SecurityFilterChain securityFilterChain(HttpSecurity httpSecurity) throws Exception {

		httpSecurity = httpSecurity.authorizeHttpRequests(authorizeRequests -> {
			authorizeRequests.requestMatchers("/register").permitAll();
			authorizeRequests.requestMatchers("/css/**").permitAll();
			authorizeRequests.requestMatchers("/icon/**").permitAll();
		}).authorizeHttpRequests(authorizeRequests -> {
			authorizeRequests.requestMatchers("/").authenticated();
			authorizeRequests.requestMatchers("/error").authenticated();
		}).formLogin(formLoginCustomizer -> {
			formLoginCustomizer
				.loginPage("/login")
				.loginProcessingUrl("/login")
				.failureUrl("/login-error")
				.usernameParameter("username")
				.passwordParameter("password")
				.defaultSuccessUrl("/")
				.permitAll();
		}).logout(logoutCustomizer -> {
			logoutCustomizer
				.logoutUrl("/logout")
				.invalidateHttpSession(true)
				.deleteCookies("JSESSIONID")
				.logoutSuccessUrl("/");
		}).csrf(csrfCustomizer -> {
			csrfCustomizer.disable();
		});
		return httpSecurity.build();
	}
} 
