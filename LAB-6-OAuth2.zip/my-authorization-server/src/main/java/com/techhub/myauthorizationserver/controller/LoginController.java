package com.techhub.myauthorizationserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.ModelAndView;

import com.techhub.myauthorizationserver.dto.UserDTO;
import com.techhub.myauthorizationserver.service.UserService;

@Controller
public class LoginController {

	@Autowired
	private UserService userService;

	@GetMapping("/login")
	public ModelAndView login() {

		System.out.println("******* Loging *******");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		ModelAndView modelAndView = new ModelAndView();
		if (currentPrincipalName.equals("anonymousUser")) {
			modelAndView.setViewName("login");
		} else {
			modelAndView.setViewName("redirect:/");
		}
		return modelAndView;
	}

	@GetMapping("/login-error")
	public ModelAndView loginFail(Model model) {

		System.out.println("******* Loging Faild *******");
		ModelAndView modelAndView = new ModelAndView("login");
		model.addAttribute("error_msg", "Username or password incorrect");
		return modelAndView;
	}

	@GetMapping("/register")
	public ModelAndView registerPage(Model model) {

		System.out.println("******* Show Registration *******");
		Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
		String currentPrincipalName = authentication.getName();
		ModelAndView modelAndView = new ModelAndView();
		if (currentPrincipalName.equals("anonymousUser")) {
			model.addAttribute("myuser", new UserDTO());
			modelAndView.setViewName("registration");
		} else {
			modelAndView.setViewName("redirect:/");
		}
		return modelAndView;
	}

	@PostMapping("/register")
	public ModelAndView registerRegister(@ModelAttribute("myuser") UserDTO myuser, Model model) {

		System.out.println("*******  Registering *******");
		UserDTO userDTO = this.userService.saveUser(myuser);
		if (userDTO == null) {
			model.addAttribute("error_msg", "Username already exists.");
		} else {
			myuser.setUsername(null);
			myuser.setPassword(null);
			model.addAttribute("success_msg", "User registered successfully.");
		}
		return new ModelAndView("registration");
	}
}
