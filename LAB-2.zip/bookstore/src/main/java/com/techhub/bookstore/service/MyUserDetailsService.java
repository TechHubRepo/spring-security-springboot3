package com.techhub.bookstore.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

import com.techhub.bookstore.dto.MyUserDetails;
import com.techhub.bookstore.dto.UserDTO;

@Service
public class MyUserDetailsService implements UserDetailsService {

	@Autowired
	private UserService userService;

	@Override
	public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
		UserDTO userDTO = userService.getUserDTO(username);
		if (userDTO == null) {
			throw new UsernameNotFoundException("User not found");
		}
		return new MyUserDetails(userDTO);
	}
}
