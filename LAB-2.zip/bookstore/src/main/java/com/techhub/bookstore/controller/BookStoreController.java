package com.techhub.bookstore.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class BookStoreController {

	@GetMapping("/show-books")
	public ModelAndView showBooks() {
		System.out.println("******* SHOW BOOKS *******");
		return new ModelAndView("show-books");
	}
	
	@GetMapping("/place-order")
	public ModelAndView placeOrder() {
		System.out.println("******* PLACE ORDER *******");
		return new ModelAndView("place-order");
	}
	
	@GetMapping("/add-book")
	public ModelAndView addBook() {
		System.out.println("******* ADD BOOK *******");
		return new ModelAndView("add-book");
	}
	
	@GetMapping("/update-book")
	public ModelAndView updateBook() {
		System.out.println("******* UPDATE BOOK *******");
		return new ModelAndView("update-book");
	}
	
	@GetMapping("/delete-book")
	public ModelAndView deleteBook() {
		System.out.println("******* DELETE BOOK *******");
		return new ModelAndView("delete-book");
	}
}
