package com.techhub.bookstore.repository;

import com.techhub.bookstore.model.User;

public interface UserRepository {
	
	public User getUser(String username);

}
