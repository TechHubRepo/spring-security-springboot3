package com.techhub.myresourceserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyresourceserverApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyresourceserverApplication.class, args);
	}
}
