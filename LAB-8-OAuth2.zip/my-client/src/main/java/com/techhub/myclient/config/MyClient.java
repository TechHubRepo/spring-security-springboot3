package com.techhub.myclient.config;

import org.springframework.web.service.annotation.GetExchange;
import org.springframework.web.service.annotation.HttpExchange;


@HttpExchange("http://localhost:4301")
public interface MyClient {

	@GetExchange("/res/my-res")
	String getMyRes();

}
