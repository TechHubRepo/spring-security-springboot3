package com.techhub.myauthorizationserver.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.techhub.myauthorizationserver.dto.ClientDTO;
import com.techhub.myauthorizationserver.service.ClientService;

@Controller
@RequestMapping("/client")
public class ClientController {

	@Autowired
	private ClientService clientService;

	@GetMapping(value = { "/register" })
	public ModelAndView showClientRegisteration(Model model) {
		System.out.println("******* Show Client Registration *******");
		model.addAttribute("client", new ClientDTO());
		return new ModelAndView("client_register");
	}

	@PostMapping("/register")
	public ModelAndView registerClient(@ModelAttribute("client") ClientDTO client, Model model) {
		System.out.println("******* Registering Client *******");

		ClientDTO clientDTO = clientService.save(client);
		if (clientDTO == null) {
			model.addAttribute("error_msg", "Clientid already exists.");
		} else {
			client.setId(null);
			client.setClientId(null);
			client.setClientSecret(null);
			client.setClientName(null);
			client.setAuthorizationGrantTypes(null);
			client.setClientAuthenticationMethods(null);
			client.setClientIdIssuedAt(null);
			client.setClientSecretExpiresAt(null);
			client.setPostLogoutRedirectUris(null);
			client.setRedirectUris(null);
			client.setScopes(null);
			model.addAttribute("success_msg", "Client registered successfully.");
		}

		return new ModelAndView("client_register");
	}
}
