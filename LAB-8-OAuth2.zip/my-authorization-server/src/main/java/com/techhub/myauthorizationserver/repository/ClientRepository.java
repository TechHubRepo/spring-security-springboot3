package com.techhub.myauthorizationserver.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.techhub.myauthorizationserver.model.Client;

@Repository
@Transactional
public interface ClientRepository extends JpaRepository<Client, String> {

	public Optional<Client> getByClientId(String clientId);

}
