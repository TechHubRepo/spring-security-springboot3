package com.techhub.myauthorizationserver.service;

import com.techhub.myauthorizationserver.dto.ClientDTO;

public interface ClientService {

	public ClientDTO save(ClientDTO clientDTO);

}
