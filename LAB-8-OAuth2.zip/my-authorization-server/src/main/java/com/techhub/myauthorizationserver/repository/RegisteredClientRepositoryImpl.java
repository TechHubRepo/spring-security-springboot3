package com.techhub.myauthorizationserver.repository;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.stereotype.Repository;

import com.techhub.myauthorizationserver.adaptor.ClientAdaptor;
import com.techhub.myauthorizationserver.model.Client;

@Repository
public class RegisteredClientRepositoryImpl implements RegisteredClientRepository {

	@Autowired
	private ClientRepository clientRepository;

	@Override
	public void save(RegisteredClient registeredClient) {
		return;
	}

	@Override
	public RegisteredClient findById(String id) {
		Optional<Client> clientOptional = this.clientRepository.findById(id);
		if (clientOptional.isPresent()) {
			return ClientAdaptor.toRegisteredClient(clientOptional.get());
		}
		return null;
	}

	@Override
	public RegisteredClient findByClientId(String clientId) {
		Optional<Client> clientOptional = this.clientRepository.getByClientId(clientId);
		if (clientOptional.isPresent()) {	
			return ClientAdaptor.toRegisteredClient(clientOptional.get());
		}
		return null;
	}
}
