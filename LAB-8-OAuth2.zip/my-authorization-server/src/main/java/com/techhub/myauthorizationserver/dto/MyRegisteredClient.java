package com.techhub.myauthorizationserver.dto;

import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;

public class MyRegisteredClient extends RegisteredClient{

	private static final long serialVersionUID = 1L;
	
	public MyRegisteredClient () {
		super();		
	}

}
