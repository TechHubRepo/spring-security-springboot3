package com.techhub.myauthorizationserver.service;

import java.sql.Date;
import java.time.LocalDate;
import java.util.Optional;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.techhub.myauthorizationserver.adaptor.ClientAdaptor;
import com.techhub.myauthorizationserver.dto.ClientDTO;
import com.techhub.myauthorizationserver.model.Client;
import com.techhub.myauthorizationserver.repository.ClientRepository;

@Service
public class ClientServiceImpl implements ClientService {

	@Autowired
	private ClientRepository clientRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@Override
	public ClientDTO save(ClientDTO clientDTO) {
		Optional<Client> clientOptional = clientRepository.findById(clientDTO.getClientId());
		if (clientOptional.isPresent()) {
			return null;
		} else {
			Client client = ClientAdaptor.toClient(clientDTO);

			client.setId(UUID.randomUUID().toString());

			client.setClientIdIssuedAt(Date.valueOf(LocalDate.now()));

			client.setClientSecretExpiresAt(Date.valueOf(LocalDate.now().plusDays(2)));

			String secret = passwordEncoder.encode(client.getClientSecret());
			client.setClientSecret(secret);

			client = this.clientRepository.save(client);

			return ClientAdaptor.toClientDTO(client);
		}
	}

}
