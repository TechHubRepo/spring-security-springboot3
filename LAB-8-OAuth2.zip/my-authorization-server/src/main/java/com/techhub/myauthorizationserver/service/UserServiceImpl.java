package com.techhub.myauthorizationserver.service;

import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import com.techhub.myauthorizationserver.adaptor.UserAdaptor;
import com.techhub.myauthorizationserver.dto.UserDTO;
import com.techhub.myauthorizationserver.model.User;
import com.techhub.myauthorizationserver.repository.UserRepository;

import jakarta.annotation.PostConstruct;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserRepository userRepository;

	@Autowired
	private PasswordEncoder passwordEncoder;

	@PostConstruct
	public void addDefaultAdminUser() {
		UserDTO userDTO = new UserDTO("admin", "admin", "ADMIN");
		this.saveUser(userDTO);
	}

	@Override
	public UserDTO getUser(String username) {
		Optional<User> userOptional = userRepository.findById(username);
		if (userOptional.isPresent()) {
			return UserAdaptor.toUserDTO(userOptional.get());
		}
		return null;
	}

	@Override
	public UserDTO saveUser(UserDTO userDTO) {

		Optional<User> userOptional = userRepository.findById(userDTO.getUsername());
		if (userOptional.isPresent()) {
			return null;
		} else {
			User user = UserAdaptor.toUser(userDTO);
			String password = passwordEncoder.encode(user.getPassword());
			user.setPassword(password);
			user = this.userRepository.save(user);
			return UserAdaptor.toUserDTO(user);
		}
	}
}
