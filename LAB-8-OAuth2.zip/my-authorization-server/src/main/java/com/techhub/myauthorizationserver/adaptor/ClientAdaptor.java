package com.techhub.myauthorizationserver.adaptor;

import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient.Builder;

import com.techhub.myauthorizationserver.dto.ClientDTO;
import com.techhub.myauthorizationserver.model.Client;

public final class ClientAdaptor {

	private ClientAdaptor() {
	}

	public static final Client toClient(ClientDTO clientDTO) {
		Client client = new Client();
		client.setId(clientDTO.getId());
		client.setClientId(clientDTO.getClientId());
		client.setClientSecret(clientDTO.getClientSecret());
		client.setClientName(clientDTO.getClientName());
		client.setAuthorizationGrantTypes(clientDTO.getAuthorizationGrantTypes());
		client.setClientAuthenticationMethods(clientDTO.getClientAuthenticationMethods());
		client.setClientIdIssuedAt(clientDTO.getClientIdIssuedAt());
		client.setClientSecretExpiresAt(clientDTO.getClientSecretExpiresAt());
		client.setPostLogoutRedirectUris(clientDTO.getPostLogoutRedirectUris());
		client.setRedirectUris(clientDTO.getRedirectUris());
		client.setScopes(clientDTO.getScopes());
		return client;
	}

	public static final ClientDTO toClientDTO(Client client) {
		ClientDTO clientDTO = new ClientDTO();
		clientDTO.setId(client.getId());
		clientDTO.setClientId(client.getClientId());
		clientDTO.setClientSecret(client.getClientSecret());
		clientDTO.setClientName(client.getClientName());
		clientDTO.setAuthorizationGrantTypes(client.getAuthorizationGrantTypes());
		clientDTO.setClientAuthenticationMethods(client.getClientAuthenticationMethods());
		clientDTO.setClientIdIssuedAt(client.getClientIdIssuedAt());
		clientDTO.setClientSecretExpiresAt(client.getClientSecretExpiresAt());
		clientDTO.setPostLogoutRedirectUris(client.getPostLogoutRedirectUris());
		clientDTO.setRedirectUris(client.getRedirectUris());
		clientDTO.setScopes(client.getScopes());
		return clientDTO;
	}

	public static final RegisteredClient toRegisteredClient(Client client) {
		Builder builder = RegisteredClient.withId(
				 client.getId()).clientId(client.getClientId())
				.clientSecret(client.getClientSecret());

		for (String scope : client.getScopes()) {
			if(scope.isBlank()) {
				continue;
			}
			builder.scope(scope);
		}

		for (String redirectURI : client.getRedirectUris()) {
			if(redirectURI.isBlank()) {
				continue;
			}
			builder.redirectUri(redirectURI);
		}

		for (String authorizatioMethod : client.getClientAuthenticationMethods()) {
			if(authorizatioMethod.isBlank()) {
				continue;
			}
			builder.clientAuthenticationMethod(new ClientAuthenticationMethod(authorizatioMethod));
		}

		for (String grantType : client.getAuthorizationGrantTypes()) {
			if(grantType.isBlank()) {
				continue;
			}
			builder.authorizationGrantType(new AuthorizationGrantType(grantType));
		}

		return builder.build();
	}
}
