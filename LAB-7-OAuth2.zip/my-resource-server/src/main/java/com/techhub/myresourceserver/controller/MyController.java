package com.techhub.myresourceserver.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/res")
public class MyController {

	@GetMapping(value = "/my-res")
	public ResponseEntity<String> myResource() {
		System.out.println("********** Accessing my resource from resource server **********"); 
		return new ResponseEntity<>("Hello World, This is My Resource", HttpStatus.OK);
	}
}
