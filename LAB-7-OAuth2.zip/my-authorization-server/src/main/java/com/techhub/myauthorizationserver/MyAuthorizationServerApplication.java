package com.techhub.myauthorizationserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyAuthorizationServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyAuthorizationServerApplication.class, args);
	}
}
