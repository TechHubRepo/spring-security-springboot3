package com.techhub.myauthorizationserver.dto;

import java.util.ArrayList;
import java.util.Collection;
import java.util.List;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

public class UserDetailsImpl implements UserDetails {

	private static final long serialVersionUID = 1L;

	private UserDTO userDTO;

	public UserDetailsImpl(UserDTO userDTO) {
		this.userDTO = userDTO;
	}

	@Override
	public Collection<? extends GrantedAuthority> getAuthorities() {
		List<SimpleGrantedAuthority> authorities = new ArrayList<>();
		if (this.userDTO.getRoles() != null) {
			String roles[] = this.userDTO.getRoles().split(",");
			for (String role : roles) {
				authorities.add(new SimpleGrantedAuthority(role));
			}
		}
		return authorities;
	}

	@Override
	public String getPassword() {
		return userDTO.getPassword();
	}

	@Override
	public String getUsername() {
		return userDTO.getUsername();
	}

	@Override
	public boolean isAccountNonExpired() {
		return userDTO.isAccountNonExpired();
	}

	@Override
	public boolean isAccountNonLocked() {
		return userDTO.isAccountNonLocked();
	}

	@Override
	public boolean isCredentialsNonExpired() {

		return userDTO.isCredentialsNonExpired();
	}

	@Override
	public boolean isEnabled() {
		return userDTO.isEnabled();
	}
}
