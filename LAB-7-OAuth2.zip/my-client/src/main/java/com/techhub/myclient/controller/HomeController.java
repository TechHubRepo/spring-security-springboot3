package com.techhub.myclient.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import com.techhub.myclient.config.MyClient;


@RestController
public class HomeController {

	@Autowired
	private MyClient myClient;

	@GetMapping("/")
	public String welcome() {
		System.out.println("********** Accessing Client Application **********"); 
		String res = myClient.getMyRes();
		return "<h1>" + res + "</h1>";
	}
}
